# Ship Window

Adds a glass window to the drop ship so you can see outside. The Company didn't see it as important, so they put the terminal computer in front of it. Be sure to move that!

All players must install this mod or there may be desync issues.

## Planned

- See orbited moon from space

## Update History

- **1.1.0**
    - Add config settings for controlling window shutter, outside space props, and outside space volume.

- **1.0.7**
    - Fix network object being destroyed for some reason. (?)

- **1.0.6**
    - Re-add window shutter and outside view in space.

- **1.0.5**
    - Disable window shutter and stars (big oof). Will add back soon.

- **1.0.4**
    - Add a shutter to the window while loading.
    - Fix stars being visible at Company Building.

- **1.0.3**
    - Fix stars being always visible and enemies being invisible through glass.

- **1.0.2**
    - Update description.

- **1.0.1**
    - Added stars outside the window while in space.

- **1.0.0**
    - Initial release.